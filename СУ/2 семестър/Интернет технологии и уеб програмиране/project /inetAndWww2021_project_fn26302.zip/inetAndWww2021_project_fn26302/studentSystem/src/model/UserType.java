package model;

public enum UserType {
	STUDENT, TEACHER;
}
