package dao;

public class UserNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4130724136546391019L;

	public UserNotFoundException(String message) {
		super(message);
	}
	
}
