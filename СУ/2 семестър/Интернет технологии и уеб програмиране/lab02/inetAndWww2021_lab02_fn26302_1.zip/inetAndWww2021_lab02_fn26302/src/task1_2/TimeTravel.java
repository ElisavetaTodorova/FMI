package task1_2;

import java.util.Date;

public class TimeTravel {

  @RequestForEnhancement(id = 543, engineer = "Gosho", date = "2011-08-12T20:17:46Z")
  public static void supperFeature(Date destination) {
  }
}
