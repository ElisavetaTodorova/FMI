Архивът съдържа папка docs, където се намира документацията и два джава файла:
task1_1.Student.java и task1_1.ClassPreamble.java.
Също и двата класа за TimeTravel.java и RequestForEnhancement.java за изпълнение на задача 1.2 и 1.3 