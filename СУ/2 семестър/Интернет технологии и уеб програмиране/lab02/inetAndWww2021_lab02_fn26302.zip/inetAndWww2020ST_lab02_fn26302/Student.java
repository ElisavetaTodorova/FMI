import java.lang.annotation.Documented;

/**
 * Representation of final class Student
 * @author Elisaveta Todorova
 */

@ClassPreamble(author = "Mr. Flinstone", date = "30.12.2009",
    currentRevision = 1, lastModified = "10.10.2010",
    by = "Peter Petrov", reviewers = {"Ivan", "Maria", "Jordan"})
public final class Student {

  private String name;
  private String fNumber;
}
