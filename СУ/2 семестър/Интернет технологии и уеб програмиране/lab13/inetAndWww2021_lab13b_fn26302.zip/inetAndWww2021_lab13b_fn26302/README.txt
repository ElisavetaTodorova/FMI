Архива съдържа файл lab13b.xhtml в който са добавени OrderedList, Gmap и Basic TimeLine
Също и два класа нужни за имплементацията на OrderedList и Basic TimeLine.
Зачата е изпълненат на 100%