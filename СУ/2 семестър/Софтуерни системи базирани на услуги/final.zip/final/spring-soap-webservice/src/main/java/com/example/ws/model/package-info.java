
@XmlSchema(
        namespace = "http://localhost:9091/types/SendEmailInput",
        elementFormDefault = XmlNsForm.QUALIFIED)
package com.example.ws.model;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
